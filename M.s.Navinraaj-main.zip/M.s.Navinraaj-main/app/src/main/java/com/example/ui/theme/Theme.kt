package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Clean Minimalism light color system (Extracted from UI Guidelines)
private val LightColorScheme = lightColorScheme(
    primary = MinPrimaryAccent,
    secondary = MinOnPrimaryContainer,
    tertiary = MinTextMuted,
    background = MinBg,
    surface = MinSurface,
    onPrimary = Color.White,
    onSecondary = MinTextPrimary,
    onBackground = MinTextPrimary,
    onSurface = MinTextPrimary,
    surfaceVariant = MinNavBg,
    outline = MinBorder
)

private val DarkColorScheme = lightColorScheme(
    primary = MinPrimaryAccent,
    secondary = MinOnPrimaryContainer,
    tertiary = MinTextMuted,
    background = MinBg,
    surface = MinSurface,
    onPrimary = Color.White,
    onSecondary = MinTextPrimary,
    onBackground = MinTextPrimary,
    onSurface = MinTextPrimary,
    surfaceVariant = MinNavBg,
    outline = MinBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Always force the elegant light "Clean Minimalism" theme
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
