package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.RewardRepository
import com.example.data.RewardTransaction
import com.example.viewmodel.RewardViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.CharcoalBg
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalCardVariant
import com.example.ui.theme.TextWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.AccGreen
import com.example.ui.theme.AccBlue
import com.example.ui.theme.AccRed
import com.example.ui.theme.MathTaskBg
import com.example.ui.theme.MathTaskText
import com.example.ui.theme.VideoTaskBg
import com.example.ui.theme.VideoTaskText
import com.example.ui.theme.SurveyTaskBg
import com.example.ui.theme.SurveyTaskText
import com.example.ui.theme.MinPrimaryContainer
import com.example.ui.theme.MinOnPrimaryContainer
import com.example.ui.theme.MinNavBg
import com.example.ui.theme.MinBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(this)
        val repository = RewardRepository(database.rewardDao())
        val viewModelFactory = RewardViewModel.Factory(repository)

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = CharcoalBg
                ) { innerPadding ->
                    EasyRewardsApp(
                        factory = viewModelFactory,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

enum class NavigationTab {
    HOME, WALLET, RANKS, MORE
}

@Composable
fun EasyRewardsApp(
    factory: RewardViewModel.Factory,
    modifier: Modifier = Modifier,
    viewModel: RewardViewModel = viewModel(factory = factory)
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    val totalPoints by viewModel.totalPoints.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val todayMathCount by viewModel.todayMathCount.collectAsState()
    val todayVideoCount by viewModel.todayVideoCount.collectAsState()
    val todaySurveyCompleted by viewModel.todaySurveyCompleted.collectAsState()

    val activeVideo by viewModel.selectedVideo.collectAsState()

    // Screen tab selection (Home, Wallet, Ranks, More)
    var currentTab by remember { mutableStateOf(NavigationTab.HOME) }
    
    // Expandable cards state helper
    var expandedTaskSection by remember { mutableStateOf<String?>("MATH") } // NULL, "MATH", "VIDEO", "SURVEY"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Clean Minimal App Bar Header (Incorporating Design HTML spec)
            HeaderSection(
                userEmail = "msnavinraajraaj@gmail.com",
                onProfileClick = {
                    Toast.makeText(context, "Logged in as msnavinraajraaj@gmail.com", Toast.LENGTH_SHORT).show()
                },
                onNotificationClick = {
                    Toast.makeText(context, "No new reward campaigns today. Quota is ready!", Toast.LENGTH_SHORT).show()
                }
            )

            // Dynamic Content Switcher based on standard active pills
            Box(modifier = Modifier.weight(1f)) {
                when (currentTab) {
                    NavigationTab.HOME -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item { Spacer(modifier = Modifier.height(4.dp)) }

                            // High Fidelity Points Counter Widget
                            item {
                                PointsDashboardWidget(
                                    points = totalPoints,
                                    onRedeemClick = {
                                        currentTab = NavigationTab.WALLET
                                    }
                                )
                            }

                            // Daily Quota Summary Badges
                            item {
                                DailyQuotaSummaryPanel(
                                    mathSolved = todayMathCount,
                                    videosWatched = todayVideoCount,
                                    surveyDone = todaySurveyCompleted
                                )
                            }

                            // Task Header Section
                            item {
                                Text(
                                    text = "DAILY TASKS",
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                                )
                            }

                            // --- QUEST 1: MATH CHALLENGE ---
                            item {
                                val isExpanded = expandedTaskSection == "MATH"
                                QuestCardWrapper(
                                    title = "Quick Math Quiz",
                                    subtitle = "Complete daily mathematical arithmetic",
                                    rewardText = "+2.00 PTS",
                                    quotaText = "$todayMathCount/5 Solved",
                                    iconColor = MathTaskText,
                                    iconBgColor = MathTaskBg,
                                    icon = { Icon(Icons.Default.Star, contentDescription = null, tint = MathTaskText) },
                                    isExpanded = isExpanded,
                                    onToggle = { expandedTaskSection = if (isExpanded) null else "MATH" },
                                    testTag = "math_card_header"
                                ) {
                                    MathPuzzleSection(viewModel = viewModel, solvedCount = todayMathCount)
                                }
                            }

                            // --- QUEST 2: VIDEO WATCHING ---
                            item {
                                val isExpanded = expandedTaskSection == "VIDEO"
                                QuestCardWrapper(
                                    title = "Watch & Earn",
                                    subtitle = "Short video sponsorship task",
                                    rewardText = "+5.00 PTS",
                                    quotaText = "$todayVideoCount/3 Clips",
                                    iconColor = VideoTaskText,
                                    iconBgColor = VideoTaskBg,
                                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = VideoTaskText) },
                                    isExpanded = isExpanded,
                                    onToggle = { expandedTaskSection = if (isExpanded) null else "VIDEO" },
                                    testTag = "video_card_header"
                                ) {
                                    VideoWatchingSection(
                                        viewModel = viewModel,
                                        todayVideoCount = todayVideoCount,
                                        onSelectVideo = { video ->
                                            viewModel.selectVideo(video)
                                        }
                                    )
                                }
                            }

                            // --- QUEST 3: OPINION SURVEY ---
                            item {
                                val isExpanded = expandedTaskSection == "SURVEY"
                                QuestCardWrapper(
                                    title = "Opinion Survey",
                                    subtitle = "Profile interests & feedback review",
                                    rewardText = "+10.00 PTS",
                                    quotaText = if (todaySurveyCompleted) "100% Claimed" else "Available",
                                    iconColor = SurveyTaskText,
                                    iconBgColor = SurveyTaskBg,
                                    icon = { Icon(Icons.Default.Info, contentDescription = null, tint = SurveyTaskText) },
                                    isExpanded = isExpanded,
                                    onToggle = { expandedTaskSection = if (isExpanded) null else "SURVEY" },
                                    testTag = "survey_card_header"
                                ) {
                                    SurveyTaskSection(viewModel = viewModel, completedToday = todaySurveyCompleted)
                                }
                            }

                            // Dynamic Claim History Header
                            item {
                                Text(
                                    text = "CLAIM HISTORY",
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(start = 2.dp, end = 2.dp, top = 16.dp, bottom = 4.dp)
                                )
                            }

                            if (transactions.isEmpty()) {
                                item {
                                    EmptyHistoryPlaceholder()
                                }
                            } else {
                                items(transactions) { tx ->
                                    HistoryItemRow(transaction = tx)
                                }
                            }

                            item { Spacer(modifier = Modifier.height(24.dp)) }
                        }
                    }
                    
                    NavigationTab.WALLET -> {
                        WalletScreen(
                            totalPoints = totalPoints,
                            dbViewModel = viewModel,
                            onCashoutSuccess = { method, amt ->
                                Toast.makeText(context, "Successfully cashed out $amt PTS to your $method wallet! 🎉", Toast.LENGTH_LONG).show()
                            },
                            onInsufficientFunds = { required ->
                                Toast.makeText(context, "Insufficient points. You need at least $required PTS to cash out! Solve quizzes to earn.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    NavigationTab.RANKS -> {
                        RanksScreen(
                            userPoints = totalPoints
                        )
                    }

                    NavigationTab.MORE -> {
                        MoreSettingsScreen(
                            userEmail = "msnavinraajraaj@gmail.com",
                            viewModel = viewModel,
                            onClearSuccess = {
                                Toast.makeText(context, "All points & histories have been securely reset to onboarding defaults.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // Bottom Navigation Bar (MD3 Clean Minimalism implementation)
            MinimalistBottomNavigation(
                activeTab = currentTab,
                onTabSelect = { currentTab = it }
            )
        }

        // Animated Immersive Mock Video Player Dialog
        activeVideo?.let { video ->
            AnimatedVisibility(
                visible = true,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
            ) {
                MockVideoPlayerOverlay(
                    video = video,
                    viewModel = viewModel,
                    todayVideoCount = todayVideoCount
                )
            }
        }
    }
}

@Composable
fun HeaderSection(
    userEmail: String,
    onProfileClick: () -> Unit,
    onNotificationClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(CharcoalBg)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Rounded light grey-green avatar capsule
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(MinBorder, CircleShape)
                .clip(CircleShape)
                .clickable { onProfileClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "User profile options",
                tint = TextMuted,
                modifier = Modifier.size(24.dp)
            )
        }

        Text(
            text = "Easy Rewards",
            color = TextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center
        )

        // Notification badge icon
        IconButton(
            onClick = { onNotificationClick() },
            modifier = Modifier
                .size(40.dp)
                .background(Color.Transparent, CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Inbox notices",
                tint = TextMuted,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun PointsDashboardWidget(
    points: Double,
    onRedeemClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("points_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MinPrimaryContainer),
        border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CURRENT BALANCE",
                color = MinOnPrimaryContainer,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = String.format(Locale.US, "%.2f", points),
                    color = MinOnPrimaryContainer,
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.testTag("points_balance_text")
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "PTS",
                    color = MinOnPrimaryContainer.copy(alpha = 0.7f),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Redeem Active Pill
            Button(
                onClick = onRedeemClick,
                colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                shape = RoundedCornerShape(50.dp),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp),
                modifier = Modifier.testTag("redeem_points_nav_button")
            ) {
                Text(
                    text = "Redeem Points",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun DailyQuotaSummaryPanel(
    mathSolved: Int,
    videosWatched: Int,
    surveyDone: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuotaBadge(
            title = "Maths Quiz",
            progressText = "$mathSolved/5",
            completed = mathSolved >= 5,
            modifier = Modifier.weight(1f)
        )
        QuotaBadge(
            title = "Watch Clip",
            progressText = "$videosWatched/3",
            completed = videosWatched >= 3,
            modifier = Modifier.weight(1f)
        )
        QuotaBadge(
            title = "Daily Survey",
            progressText = if (surveyDone) "100%" else "0%",
            completed = surveyDone,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun QuotaBadge(
    title: String,
    progressText: String,
    completed: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(72.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (completed) MinNavBg else CharcoalSurface
        ),
        border = BorderStroke(
            1.dp,
            if (completed) AccGreen.copy(alpha = 0.3f) else MinBorder.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (completed) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = AccGreen,
                        modifier = Modifier
                            .size(13.dp)
                            .padding(end = 2.dp)
                    )
                }
                Text(
                    text = progressText,
                    color = if (completed) AccGreen else TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun QuestCardWrapper(
    title: String,
    subtitle: String,
    rewardText: String,
    quotaText: String,
    iconColor: Color,
    iconBgColor: Color,
    icon: @Composable () -> Unit,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    testTag: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessLow)),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        border = BorderStroke(1.dp, if (isExpanded) AmberPrimary.copy(alpha = 0.3f) else MinBorder.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(16.dp)
                    .testTag(testTag),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(iconBgColor, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    icon()
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = subtitle,
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = rewardText,
                        color = iconColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = quotaText,
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
            }

            if (isExpanded) {
                HorizontalDivider(color = MinBorder.copy(alpha = 0.4f), modifier = Modifier.padding(horizontal = 16.dp))
                Box(modifier = Modifier.padding(16.dp)) {
                    content()
                }
            }
        }
    }
}

// ------ QUEST VIEWS ------

@Composable
fun MathPuzzleSection(
    viewModel: RewardViewModel,
    solvedCount: Int
) {
    val num1 by viewModel.mathNum1.collectAsState()
    val num2 by viewModel.mathNum2.collectAsState()
    val op by viewModel.mathOperator.collectAsState()
    val answerVal by viewModel.mathAnswerInput.collectAsState()
    val feedback by viewModel.mathFeedback.collectAsState()
    val isCorrect by viewModel.mathIsCorrect.collectAsState()

    val maxReached = solvedCount >= 5
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Solve arithmetic and earn +2.00 Points",
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Math Question Card UI
        Card(
            colors = CardDefaults.cardColors(containerColor = MinNavBg),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "WHAT IS THE RESULT OF:",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "$num1 $op $num2 = ?",
                    color = TextWhite,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("math_question_text")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Clean answer input
        OutlinedTextField(
            value = answerVal,
            onValueChange = { viewModel.setMathAnswerInput(it) },
            label = { Text("Enter Answer") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedBorderColor = AmberPrimary,
                unfocusedBorderColor = MinBorder,
                focusedLabelColor = AmberPrimary,
                unfocusedLabelColor = TextMuted
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    focusManager.clearFocus()
                    if (!maxReached) viewModel.submitMathAnswer()
                }
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("math_answer_input"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Check button
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.submitMathAnswer()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("math_submit_button")
            ) {
                Text(
                    text = "Submit Check",
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
            }

            // Next question button
            OutlinedButton(
                onClick = {
                    viewModel.generateNewMathPuzzle()
                },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MinBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                modifier = Modifier
                    .height(48.dp)
                    .width(72.dp)
                    .testTag("math_next_puzzle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "New question",
                    tint = TextWhite
                )
            }
        }

        feedback?.let { msg ->
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isCorrect == true) MathTaskBg else VideoTaskBg
                ),
                border = BorderStroke(
                    1.dp,
                    if (isCorrect == true) MathTaskText.copy(alpha = 0.3f) else VideoTaskText.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    color = if (isCorrect == true) MathTaskText else VideoTaskText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .testTag("math_feedback_text")
                )
            }
        }

        if (maxReached) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "💡 Daily maths rewards limit (5/5) reached. Solves still practice logical arithmetic conceptually!",
                color = MathTaskText,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
fun VideoWatchingSection(
    viewModel: RewardViewModel,
    todayVideoCount: Int,
    onSelectVideo: (com.example.viewmodel.VideoItem) -> Unit
) {
    val isMaxQuota = todayVideoCount >= 3

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Select any video task & claim +5.00 PTS upon timer completion.",
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        viewModel.videos.forEach { video ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onSelectVideo(video) }
                    .testTag("video_task_${video.id}"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MinNavBg),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(VideoTaskBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Watch video",
                            tint = VideoTaskText,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = video.title,
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⏱️ ${video.duration}",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "⭐ +5.00 PTS",
                                color = VideoTaskText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Configure task",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        if (isMaxQuota) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "⚠️ Daily video task quota complete (3/3). Watch more sponsorship conceptually without scoring rewards.",
                color = VideoTaskText,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun SurveyTaskSection(
    viewModel: RewardViewModel,
    completedToday: Boolean
) {
    val activeStep by viewModel.surveyStep.collectAsState()
    val q1Answer by viewModel.surveyQ1Answer.collectAsState()
    val q2Answer by viewModel.surveyQ2Answer.collectAsState()
    val q3Answers by viewModel.surveyQ3Answers.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("survey_section_content"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (completedToday && activeStep != 4) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MinNavBg),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Completed Survey Today",
                        tint = SurveyTaskText,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Survey Daily Complete 🌟",
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "You claimed exactly 10.00 Survey Points. Refresh happens daily at midnight!",
                        color = TextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(onClick = { viewModel.resetSurvey() }) {
                        Text("Retake Survey conceptually (for testing)", color = SurveyTaskText, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            when (activeStep) {
                1 -> {
                    SurveyStepOneView(
                        selectedAnswer = q1Answer,
                        onSelect = { viewModel.selectSurveyQ1(it) },
                        onNext = { viewModel.advanceSurveyStep() }
                    )
                }
                2 -> {
                    SurveyStepTwoView(
                        rating = q2Answer,
                        onRateSet = { viewModel.setSurveyQ2(it) },
                        onNext = { viewModel.advanceSurveyStep() }
                    )
                }
                3 -> {
                    SurveyStepThreeView(
                        selectedMethods = q3Answers,
                        onToggle = { viewModel.toggleSurveyQ3(it) },
                        onNext = { viewModel.advanceSurveyStep() }
                    )
                }
                4 -> {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = SurveyTaskText,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Claimed +10.00 PTS! 🎉",
                            color = TextWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "A sum of 10.00 Points has been securely calculated into your balance ledger history.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.resetSurvey() },
                            colors = ButtonDefaults.buttonColors(containerColor = MinNavBg),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Restart survey mock", color = TextWhite)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SurveyStepOneView(
    selectedAnswer: String,
    onSelect: (String) -> Unit,
    onNext: () -> Unit
) {
    val options = listOf("Save points for giftcards", "Play maths challenges", "Enjoy video content", "Check layout animations")

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "STEP 1 OF 3",
            color = SurveyTaskText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "What is your primary goal while using Easy Rewards?",
            color = TextWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        options.forEach { opt ->
            val isSelected = selectedAnswer == opt
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onSelect(opt) }
                    .testTag("survey_opt_$opt"),
                border = BorderStroke(
                    1.dp,
                    if (isSelected) SurveyTaskText else MinBorder.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) SurveyTaskBg else MinNavBg
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onSelect(opt) },
                        colors = RadioButtonDefaults.colors(selectedColor = SurveyTaskText)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = opt, color = if (isSelected) TextWhite else TextMuted, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onNext,
            enabled = selectedAnswer.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = SurveyTaskText),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("survey_next_1")
        ) {
            Text("Next Question", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SurveyStepTwoView(
    rating: Int,
    onRateSet: (Int) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "STEP 2 OF 3",
            color = SurveyTaskText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Rate your visual layout & design experience",
            color = TextWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            for (i in 1..5) {
                IconButton(
                    onClick = { onRateSet(i) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("survey_star_rate_$i")
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rate $i stars",
                        tint = if (i <= rating) SurveyTaskText else TextMuted.copy(alpha = 0.2f),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = when (rating) {
                1 -> "Really bad, layout needs polish 😢"
                2 -> "Below average styling 😕"
                3 -> "Average client dashboard 😐"
                4 -> "Good, beautiful tactile M3 design! 😊"
                5 -> "Stunning " + "Clean Minimalism" + " layout! 🤩"
                else -> ""
            },
            color = SurveyTaskText,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onNext,
            colors = ButtonDefaults.buttonColors(containerColor = SurveyTaskText),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("survey_next_2")
        ) {
            Text("Next Question", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SurveyStepThreeView(
    selectedMethods: Set<String>,
    onToggle: (String) -> Unit,
    onNext: () -> Unit
) {
    val rewards = listOf("Amazon Gift Card", "PayPal Cashout", "Google Play Voucher", "Secure Direct Crypto")

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "STEP 3 OF 3",
            color = SurveyTaskText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Which reward withdrawal models are you most excited for?",
            color = TextWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        rewards.forEach { rx ->
            val isChecked = selectedMethods.contains(rx)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onToggle(rx) }
                    .testTag("survey_check_$rx"),
                border = BorderStroke(
                    1.dp,
                    if (isChecked) SurveyTaskText else MinBorder.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isChecked) SurveyTaskBg else MinNavBg
                )
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { onToggle(rx) },
                        colors = CheckboxDefaults.colors(checkedColor = SurveyTaskText)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = rx, color = if (isChecked) TextWhite else TextMuted, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onNext,
            colors = ButtonDefaults.buttonColors(containerColor = MathTaskText),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("survey_submit_points")
        ) {
            Text("Submit & Earn 10.00 Points", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

// ------ WALLET REDEMPTION ------

@Composable
fun WalletScreen(
    totalPoints: Double,
    dbViewModel: RewardViewModel,
    onCashoutSuccess: (String, Double) -> Unit,
    onInsufficientFunds: (Double) -> Unit
) {
    val scope = rememberCoroutineScope()
    val cashRate = 0.01 // 1 PTS = $0.01 standard conversion
    val balanceDollar = totalPoints * cashRate

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MinPrimaryContainer),
                border = BorderStroke(1.dp, MinBorder)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "REDEEMABLE ASSETS",
                        color = MinOnPrimaryContainer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = String.format(Locale.US, "$%.2f", balanceDollar),
                            color = MinOnPrimaryContainer,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "USD",
                            color = MinOnPrimaryContainer.copy(alpha = 0.7f),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Transfer rate: 100 PTS = $1.00 USD securely",
                        color = MinOnPrimaryContainer.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Minimal progress bar for minimum withdrawal (10.00 PTS = $0.10 USD)
                    val minThreshold = 10.0
                    val progressRatio = (totalPoints / minThreshold).toFloat().coerceIn(0f, 1f)
                    
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Milestone progress ($minThreshold PTS min)",
                                fontSize = 11.sp,
                                color = MinOnPrimaryContainer
                            )
                            Text(
                                text = "${(progressRatio * 100).toInt()}%",
                                fontSize = 11.sp,
                                color = MinOnPrimaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = progressRatio,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = MathTaskText,
                            trackColor = Color.White.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "PAYOUT CHANNELS",
                color = TextMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
        }

        val payoutMethods = listOf(
            PayoutChannel("Amazon Gift Card", "Secure e-Voucher code", 10.0, "🎁", SurveyTaskText, SurveyTaskBg),
            PayoutChannel("PayPal Cashout", "Direct instant transfer", 15.0, "💰", MathTaskText, MathTaskBg),
            PayoutChannel("Google Play Store", "Digital play play credits", 10.0, "🕹️", VideoTaskText, VideoTaskBg),
            PayoutChannel("Direct Crypto Wallet", "USDT secure deposit", 20.0, "🪙", SurveyTaskText, SurveyTaskBg)
        )

        items(payoutMethods) { channel ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(channel.bgColor, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = channel.emoji, fontSize = 20.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = channel.name,
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Min threshold: ${String.format(Locale.US, "%.0f", channel.minPoints)} PTS",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Redeem Button
                    Button(
                        onClick = {
                            if (totalPoints >= channel.minPoints) {
                                scope.launch {
                                    dbViewModel.submitRedeemTransaction(channel.name, channel.minPoints)
                                    onCashoutSuccess(channel.name, channel.minPoints)
                                }
                            } else {
                                onInsufficientFunds(channel.minPoints)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (totalPoints >= channel.minPoints) channel.accentColor else MinBorder
                        ),
                        shape = RoundedCornerShape(50.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Withdraw",
                            color = if (totalPoints >= channel.minPoints) Color.White else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

data class PayoutChannel(
    val name: String,
    val info: String,
    val minPoints: Double,
    val emoji: String,
    val accentColor: Color,
    val bgColor: Color
)

// Extension on ViewModel to insert redeem transactions
fun RewardViewModel.submitRedeemTransaction(method: String, pts: Double) {
    val repositoryField = javaClass.getDeclaredField("repository").apply { isAccessible = true }
    val repo = repositoryField.get(this) as RewardRepository
    
    viewModelScope.launch {
        repo.insertTransaction(
            RewardTransaction(
                taskType = "REDEEM",
                points = -pts, // Deducts score points correctly
                title = "Redemption: Cashed Out via $method"
            )
        )
    }
}

// ------ GLOBAL RANKS ------

@Composable
fun RanksScreen(
    userPoints: Double
) {
    val rankTiers = listOf(
        RankTierItem("Diamond Elite", "100+ PTS", "Top 1%", VideoTaskText, VideoTaskBg, "💎"),
        RankTierItem("Gold Explorer", "50+ PTS", "Top 10%", MathTaskText, MathTaskBg, "🥇"),
        RankTierItem("Silver Solver", "20+ PTS", "Top 30%", SurveyTaskText, SurveyTaskBg, "🥈"),
        RankTierItem("Bronze Learner", "0+ PTS", "Top 100%", TextMuted, MinBorder, "🥉")
    )

    val currentTier = when {
        userPoints >= 100.0 -> "Diamond Elite"
        userPoints >= 50.0 -> "Gold Explorer"
        userPoints >= 20.0 -> "Silver Solver"
        else -> "Bronze Learner"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Core standing widget
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MinPrimaryContainer),
                border = BorderStroke(1.dp, MinBorder)
            ) {
                Row(
                    modifier = Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "YOUR STANDING TIER",
                            color = MinOnPrimaryContainer,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentTier,
                            color = MinOnPrimaryContainer,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Verify math quizzes to increase ranking speed!",
                            color = MinOnPrimaryContainer.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(MinBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when (currentTier) {
                                "Diamond Elite" -> "💎"
                                "Gold Explorer" -> "🥇"
                                "Silver Solver" -> "🥈"
                                else -> "🥉"
                            },
                            fontSize = 36.sp
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "GLOBAL RANK TIERS",
                color = TextMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
        }

        items(rankTiers) { tier ->
            val isCurrent = tier.name == currentTier
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = BorderStroke(
                    1.dp,
                    if (isCurrent) tier.color else MinBorder.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(tier.bgColor, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = tier.emoji, fontSize = 20.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tier.name,
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Required: ${tier.requirement}",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    if (isCurrent) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MathTaskBg),
                            shape = RoundedCornerShape(50.dp)
                        ) {
                            Text(
                                text = "Active",
                                color = MathTaskText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Text(
                            text = tier.distribution,
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

data class RankTierItem(
    val name: String,
    val requirement: String,
    val distribution: String,
    val color: Color,
    val bgColor: Color,
    val emoji: String
)

// ------ SETTINGS / INFO SCREEN ------

@Composable
fun MoreSettingsScreen(
    userEmail: String,
    viewModel: RewardViewModel,
    onClearSuccess: () -> Unit
) {
    var volumeSimulated by remember { mutableStateOf(true) }
    var highPrecisionTimer by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ACCOUNT INFOPACK",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "User Identifier: $userEmail",
                        fontSize = 14.sp,
                        color = TextWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Join Date: June 11, 2026",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "Verification: Legitimate & Verified 💚",
                        fontSize = 13.sp,
                        color = MathTaskText,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        item {
            Text(
                text = "APPLICATION MANAGEMENT",
                color = TextMuted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(4.dp)) {
                    // Toggle 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Tacit Audio FX", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Play soft claim tones on tasks solved", color = TextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = volumeSimulated,
                            onCheckedChange = { volumeSimulated = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = AmberPrimary)
                        )
                    }

                    HorizontalDivider(color = MinBorder.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 12.dp))

                    // Toggle 2
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "High Precision Countdown", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Deduce timer speeds by millisecond checks", color = TextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = highPrecisionTimer,
                            onCheckedChange = { highPrecisionTimer = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = AmberPrimary)
                        )
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Why Mathematics & Opinion Tasks?",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Easy Rewards operates on decentralized sponsor systems. Quick maths and brief video audits guarantee non-bot interactions, enabling reliable sponsorship distributions directly back into payment nodes.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Diagnostic wipe
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = VideoTaskBg),
                border = BorderStroke(1.dp, VideoTaskText.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Danger Zone",
                        color = VideoTaskText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "You can securely clear your local Room database progress, which returns all points balance metrics to onboarding definitions.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            viewModel.clearDatabase()
                            onClearSuccess()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VideoTaskText),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_db_button_more")
                    ) {
                        Text("Reset Wallet Progress", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

// ------ END SCREENS ------

@Composable
fun EmptyHistoryPlaceholder() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "📊",
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No Rewards Claimed",
                color = TextWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Solve arithmetic or watch media sponsorships to generate claim history logs ledger records.",
                color = TextMuted,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
    }
}

@Composable
fun HistoryItemRow(transaction: com.example.data.RewardTransaction) {
    val dateStr = remember(transaction.timestamp) {
        val df = SimpleDateFormat("HH:mm:ss", Locale.US)
        df.format(Date(transaction.timestamp))
    }

    val isPositive = transaction.points >= 0.0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        border = BorderStroke(1.dp, MinBorder.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = when (transaction.taskType) {
                            "MATH" -> MathTaskBg
                            "VIDEO" -> VideoTaskBg
                            "SURVEY" -> SurveyTaskBg
                            else -> if (isPositive) MathTaskBg else VideoTaskBg
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (transaction.taskType) {
                        "MATH" -> "➕"
                        "VIDEO" -> "▶️"
                        "SURVEY" -> "📋"
                        else -> if (isPositive) "⭐" else "💸"
                    },
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.title,
                    color = TextWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Claimed at $dateStr today",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            Text(
                text = if (isPositive) {
                    "+${String.format(Locale.US, "%.2f", transaction.points)}"
                } else {
                    "${String.format(Locale.US, "%.2f", transaction.points)}"
                },
                color = if (isPositive) MathTaskText else VideoTaskText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun MockVideoPlayerOverlay(
    video: com.example.viewmodel.VideoItem,
    viewModel: RewardViewModel,
    todayVideoCount: Int
) {
    val isPlaying by viewModel.videoIsPlaying.collectAsState()
    val isClaimable by viewModel.videoClaimable.collectAsState()
    val timerVal by viewModel.videoTimerRemaining.collectAsState()

    val durationSeconds = 15
    val currentProgress = (durationSeconds - timerVal).toFloat() / durationSeconds.toFloat()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.96f))
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SPONSOR PORTAL",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                IconButton(
                    onClick = {
                        viewModel.stopVideoWatch()
                        viewModel.claimVideoReward()
                    },
                    modifier = Modifier.testTag("video_player_close")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close player", tint = TextWhite)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Simulated Video Player Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isPlaying) "🎬 STREAMING AUDIO/VIDEO..." else "🎬 MEDIA PAUSED",
                            color = if (isPlaying) MathTaskText else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Refresh else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (isPlaying) MathTaskText else VideoTaskText,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = video.title,
                color = TextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Progress Indicators
            LinearProgressIndicator(
                progress = currentProgress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = MathTaskText,
                trackColor = Color.White.copy(alpha = 0.1f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Timer: ${timerVal}s Remaining",
                color = MathTaskText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Play / Pause Button
                Button(
                    onClick = {
                        if (isPlaying) viewModel.stopVideoWatch() else viewModel.startVideoWatch()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPlaying) VideoTaskText else MathTaskText
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("video_play_pause")
                ) {
                    Text(
                        text = if (isPlaying) "Pause Clip" else "Play Video",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Claim Button
                Button(
                    onClick = {
                        viewModel.claimVideoReward()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                    enabled = isClaimable,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("video_claim_points_button")
                ) {
                    Text(
                        text = if (isClaimable) "Claim +5.00 PTS" else "Locked",
                        color = if (isClaimable) Color.White else TextMuted,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ------ BOTTOM NAVIGATION BAR ------

@Composable
fun MinimalistBottomNavigation(
    activeTab: NavigationTab,
    onTabSelect: (NavigationTab) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars), // Strictly obey notch / navigation bar safe zones
        color = MinNavBg,
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: HOME
            BottomNavTabItem(
                label = "Home",
                imageVector = Icons.Default.Home,
                active = activeTab == NavigationTab.HOME,
                onClick = { onTabSelect(NavigationTab.HOME) },
                testTag = "nav_tab_home"
            )

            // Tab 2: WALLET
            BottomNavTabItem(
                label = "Wallet",
                imageVector = Icons.Default.ShoppingCart,
                active = activeTab == NavigationTab.WALLET,
                onClick = { onTabSelect(NavigationTab.WALLET) },
                testTag = "nav_tab_wallet"
            )

            // Tab 3: RANKS
            BottomNavTabItem(
                label = "Ranks",
                imageVector = Icons.Default.Star,
                active = activeTab == NavigationTab.RANKS,
                onClick = { onTabSelect(NavigationTab.RANKS) },
                testTag = "nav_tab_ranks"
            )

            // Tab 4: MORE
            BottomNavTabItem(
                label = "More",
                imageVector = Icons.Default.Settings,
                active = activeTab == NavigationTab.MORE,
                onClick = { onTabSelect(NavigationTab.MORE) },
                testTag = "nav_tab_more"
            )
        }
    }
}

@Composable
fun BottomNavTabItem(
    label: String,
    imageVector: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(if (active) MinPrimaryContainer else Color.Transparent)
                .padding(horizontal = 20.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = imageVector,
                contentDescription = label,
                tint = if (active) MinOnPrimaryContainer else TextMuted,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (active) TextWhite else TextMuted,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
        )
    }
}
