package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reward_transactions")
data class RewardTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskType: String, // "MATH", "VIDEO", "SURVEY", "BONUS"
    val points: Double,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)
