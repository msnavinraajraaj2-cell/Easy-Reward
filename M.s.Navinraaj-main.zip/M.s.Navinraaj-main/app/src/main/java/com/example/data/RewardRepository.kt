package com.example.data

import kotlinx.coroutines.flow.Flow

class RewardRepository(private val rewardDao: RewardDao) {
    val allTransactions: Flow<List<RewardTransaction>> = rewardDao.getAllTransactions()

    suspend fun insertTransaction(transaction: RewardTransaction) {
        rewardDao.insertTransaction(transaction)
    }

    suspend fun clearAll() {
        rewardDao.clearAllTransactions()
    }
}
