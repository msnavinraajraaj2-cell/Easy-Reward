package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Design System Colors (Extracted from Design HTML)
val MinBg = Color(0xFFF7F9F7)                  // Soft light green-gray background
val MinTextPrimary = Color(0xFF191C1B)         // Main dark contrast text
val MinTextMuted = Color(0xFF3F4943)           // Subtext / description gray-green
val MinBorder = Color(0xFFDCE5DD)              // Soft borders and separators
val MinSurface = Color(0xFFFFFFFF)             // High contrast white cards

// Primary Accent & Containers
val MinPrimaryAccent = Color(0xFF006C4C)       // Deep accent green for major buttons
val MinPrimaryContainer = Color(0xFFD7E8DE)    // Mint green points container background
val MinOnPrimaryContainer = Color(0xFF002114)  // Dark contrast forest green text
val MinNavBg = Color(0xFFF1F5F2)               // Subtle container / bottom bar fill

// Task Specific Highlights (Pastel Soft Backgrounds + Rich Text)
val MathTaskBg = Color(0xFFE8F3EB)
val MathTaskText = Color(0xFF006C4C)

val VideoTaskBg = Color(0xFFFDE8E4)
val VideoTaskText = Color(0xFF904B3E)

val SurveyTaskBg = Color(0xFFE1E2F6)
val SurveyTaskText = Color(0xFF44466F)

// Legacy mappings to guarantee robust compilation safety for existing layouts
val AmberPrimary = MinPrimaryAccent
val AmberSecondary = MinOnPrimaryContainer
val CharcoalBg = MinBg
val CharcoalSurface = MinSurface
val CharcoalCardVariant = MinNavBg

val TextWhite = MinTextPrimary
val TextMuted = MinTextMuted

val AccGreen = MinPrimaryAccent
val AccBlue = Color(0xFF2979FF)
val AccRed = Color(0xFFFF3D00)
