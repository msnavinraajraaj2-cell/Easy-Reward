package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.RewardRepository
import com.example.data.RewardTransaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.random.Random

class RewardViewModel(private val repository: RewardRepository) : ViewModel() {

    // Main transactions flow
    val transactions: StateFlow<List<RewardTransaction>> = repository.allTransactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Total points calculated from transactions
    val totalPoints: StateFlow<Double> = transactions.map { list ->
        // Start with a base of 5.0 points as an onboarding gift!
        5.00 + list.sumOf { it.points }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 5.00)

    // Helper to get start of today's timestamp
    private fun getStartOfDayTimestamp(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // Daily statistics
    val todayMathCount: StateFlow<Int> = transactions.map { list ->
        val startOfToday = getStartOfDayTimestamp()
        list.count { it.taskType == "MATH" && it.timestamp >= startOfToday }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todayVideoCount: StateFlow<Int> = transactions.map { list ->
        val startOfToday = getStartOfDayTimestamp()
        list.count { it.taskType == "VIDEO" && it.timestamp >= startOfToday }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val todaySurveyCompleted: StateFlow<Boolean> = transactions.map { list ->
        val startOfToday = getStartOfDayTimestamp()
        list.any { it.taskType == "SURVEY" && it.timestamp >= startOfToday }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // Math Challenge State
    private val _mathNum1 = MutableStateFlow(0)
    val mathNum1: StateFlow<Int> = _mathNum1.asStateFlow()

    private val _mathNum2 = MutableStateFlow(0)
    val mathNum2: StateFlow<Int> = _mathNum2.asStateFlow()

    private val _mathOperator = MutableStateFlow("+")
    val mathOperator: StateFlow<String> = _mathOperator.asStateFlow()

    private val _mathAnswerInput = MutableStateFlow("")
    val mathAnswerInput: StateFlow<String> = _mathAnswerInput.asStateFlow()

    private val _mathFeedback = MutableStateFlow<String?>(null)
    val mathFeedback: StateFlow<String?> = _mathFeedback.asStateFlow()

    private val _mathIsCorrect = MutableStateFlow<Boolean?>(null)
    val mathIsCorrect: StateFlow<Boolean?> = _mathIsCorrect.asStateFlow()

    // Video watching task list & active state
    val videos = listOf(
        VideoItem(1, "Master High Speed Mental math tricks!", 5.0, "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&q=80&w=400", "15s"),
        VideoItem(2, "Life in 2030: Tech & Daily Workflows", 5.0, "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=400", "15s"),
        VideoItem(3, "Top 5 Survey Tips & Passive Rewards guide", 5.0, "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=400", "15s")
    )

    private val _selectedVideo = MutableStateFlow<VideoItem?>(null)
    val selectedVideo: StateFlow<VideoItem?> = _selectedVideo.asStateFlow()

    private val _videoTimerRemaining = MutableStateFlow(15) // 15 seconds watching task
    val videoTimerRemaining: StateFlow<Int> = _videoTimerRemaining.asStateFlow()

    private val _videoIsPlaying = MutableStateFlow(false)
    val videoIsPlaying: StateFlow<Boolean> = _videoIsPlaying.asStateFlow()

    private val _videoClaimable = MutableStateFlow(false)
    val videoClaimable: StateFlow<Boolean> = _videoClaimable.asStateFlow()

    // Survey State
    private val _surveyStep = MutableStateFlow(1) // Steps 1 to 3, step 4 is completed view
    val surveyStep: StateFlow<Int> = _surveyStep.asStateFlow()

    private val _surveyQ1Answer = MutableStateFlow("")
    val surveyQ1Answer: StateFlow<String> = _surveyQ1Answer.asStateFlow()

    private val _surveyQ2Answer = MutableStateFlow(3) // 1 to 5 stars
    val surveyQ2Answer: StateFlow<Int> = _surveyQ2Answer.asStateFlow()

    private val _surveyQ3Answers = MutableStateFlow(setOf<String>())
    val surveyQ3Answers: StateFlow<Set<String>> = _surveyQ3Answers.asStateFlow()

    init {
        generateNewMathPuzzle()
    }

    // --- Math logical actions ---
    fun setMathAnswerInput(input: String) {
        _mathAnswerInput.value = input
    }

    fun generateNewMathPuzzle() {
        val operators = listOf("+", "-", "*")
        val op = operators[Random.nextInt(operators.size)]
        _mathOperator.value = op
        _mathAnswerInput.value = ""
        _mathFeedback.value = null
        _mathIsCorrect.value = null

        when (op) {
            "+" -> {
                _mathNum1.value = Random.nextInt(1, 100)
                _mathNum2.value = Random.nextInt(1, 100)
            }
            "-" -> {
                val n1 = Random.nextInt(10, 100)
                val n2 = Random.nextInt(1, n1)
                _mathNum1.value = n1
                _mathNum2.value = n2
            }
            "*" -> {
                _mathNum1.value = Random.nextInt(2, 12)
                _mathNum2.value = Random.nextInt(2, 12)
            }
        }
    }

    fun submitMathAnswer() {
        val input = _mathAnswerInput.value.trim().toIntOrNull()
        if (input == null) {
            _mathFeedback.value = "Enter a valid number!"
            _mathIsCorrect.value = false
            return
        }

        val expected = when (_mathOperator.value) {
            "+" -> _mathNum1.value + _mathNum2.value
            "-" -> _mathNum1.value - _mathNum2.value
            "*" -> _mathNum1.value * _mathNum2.value
            else -> 0
        }

        if (input == expected) {
            val countToday = todayMathCount.value
            if (countToday >= 5) {
                _mathFeedback.value = "Puzzle solved! (No points added, daily limit 5/5 reached)"
                _mathIsCorrect.value = true
            } else {
                _mathFeedback.value = "Perfect! Correct answer. +2.00 Points!"
                _mathIsCorrect.value = true
                viewModelScope.launch {
                    repository.insertTransaction(
                        RewardTransaction(
                            taskType = "MATH",
                            points = 2.00,
                            title = "Solved Daily Math Puzzle (${_mathNum1.value} ${_mathOperator.value} ${_mathNum2.value})"
                        )
                    )
                }
            }
        } else {
            _mathFeedback.value = "Oops! That's incorrect, try again."
            _mathIsCorrect.value = false
        }
    }

    // --- Video logical actions ---
    fun selectVideo(video: VideoItem) {
        _selectedVideo.value = video
        _videoTimerRemaining.value = 15
        _videoIsPlaying.value = false
        _videoClaimable.value = false
    }

    fun startVideoWatch() {
        if (_selectedVideo.value == null || _videoIsPlaying.value || _videoClaimable.value) return
        _videoIsPlaying.value = true
        
        // Count down logic simulated in ViewModelCoroutine
        viewModelScope.launch {
            while (_videoTimerRemaining.value > 0 && _videoIsPlaying.value) {
                kotlinx.coroutines.delay(1000)
                _videoTimerRemaining.value = _videoTimerRemaining.value - 1
            }
            if (_videoTimerRemaining.value == 0) {
                _videoIsPlaying.value = false
                _videoClaimable.value = true
            }
        }
    }

    fun stopVideoWatch() {
        _videoIsPlaying.value = false
    }

    fun claimVideoReward() {
        val video = _selectedVideo.value ?: return
        if (!_videoClaimable.value) return

        val countToday = todayVideoCount.value
        viewModelScope.launch {
            if (countToday >= 3) {
                // Reward max reached, still allow finishing but notify user
                _selectedVideo.value = null
            } else {
                repository.insertTransaction(
                    RewardTransaction(
                        taskType = "VIDEO",
                        points = video.points,
                        title = "Watched: ${video.title}"
                    )
                )
                _selectedVideo.value = null
            }
        }
    }

    // --- Survey actions ---
    fun selectSurveyQ1(answer: String) {
        _surveyQ1Answer.value = answer
    }

    fun setSurveyQ2(rating: Int) {
        _surveyQ2Answer.value = rating
    }

    fun toggleSurveyQ3(answer: String) {
        val current = _surveyQ3Answers.value.toMutableSet()
        if (current.contains(answer)) {
            current.remove(answer)
        } else {
            current.add(answer)
        }
        _surveyQ3Answers.value = current
    }

    fun advanceSurveyStep() {
        val current = _surveyStep.value
        if (current < 3) {
            _surveyStep.value = current + 1
        } else if (current == 3) {
            // Submit survey!
            if (todaySurveyCompleted.value) {
                // Already completed survey today, skip point insertion
                _surveyStep.value = 4
            } else {
                viewModelScope.launch {
                    repository.insertTransaction(
                        RewardTransaction(
                            taskType = "SURVEY",
                            points = 10.00, // Exactly 10.00 survey points as requested
                            title = "Completed UX Design & Feedback Survey"
                        )
                    )
                    _surveyStep.value = 4
                }
            }
        }
    }

    fun resetSurvey() {
        _surveyStep.value = 1
        _surveyQ1Answer.value = ""
        _surveyQ2Answer.value = 3
        _surveyQ3Answers.value = emptySet()
    }

    // Diagnostic/Reset helper
    fun clearDatabase() {
        viewModelScope.launch {
            repository.clearAll()
            generateNewMathPuzzle()
            resetSurvey()
            _selectedVideo.value = null
        }
    }

    @Suppress("UNCHECKED_CAST")
    class Factory(private val repository: RewardRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(RewardViewModel::class.java)) {
                return RewardViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

data class VideoItem(
    val id: Int,
    val title: String,
    val points: Double,
    val imageUrl: String,
    val duration: String
)
